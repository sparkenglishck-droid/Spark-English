
  # Online English Tutoring Website

  This is a code bundle for Online English Tutoring Website. The original project is available at https://www.figma.com/design/6xHYYMsAOik3eW7Pcs5aVg/Online-English-Tutoring-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  