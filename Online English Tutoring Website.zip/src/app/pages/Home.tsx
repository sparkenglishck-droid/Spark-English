import { useNavigate } from 'react-router';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Badge } from '../components/ui/badge';
import { MessageCircle, BookOpen, Award, Users, TrendingUp, Mail, MessageSquare } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import FlipCard from '../components/FlipCard';
import { useState } from 'react';
import { toast } from 'sonner';
import logo from 'figma:asset/c8a08fa9aab5e1bd052a2d62be355f3147370a48.png';
import aboutMeImage from 'figma:asset/2a8acb2fb8829abb73e2420e48625fbb9125ffe5.png';

export default function Home() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [contactForm, setContactForm] = useState({ name: '', email: '', message: '' });

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create mailto link
    const subject = encodeURIComponent(`Contact from ${contactForm.name}`);
    const body = encodeURIComponent(`Name: ${contactForm.name}\nEmail: ${contactForm.email}\n\nMessage:\n${contactForm.message}`);
    window.location.href = `mailto:spark.englishck@gmail.com?subject=${subject}&body=${body}`;
    
    toast.success('Opening your email client...');
    setContactForm({ name: '', email: '', message: '' });
  };

  const specializations = [
    {
      icon: MessageCircle,
      title: t('spec_conversational'),
      frontDescription: t('spec_conversational_desc'),
      backDescription: 'Master everyday conversations, idiomatic expressions, pronunciation, and natural flow. Build confidence speaking in real-world situations including social gatherings, travel, and casual business interactions.',
      color: '#b8d4e8', // Pastel blue
    },
    {
      icon: Award,
      title: t('spec_cambridge'),
      frontDescription: t('spec_cambridge_desc'),
      backDescription: 'Comprehensive exam strategies, practice tests, and targeted skill development. Learn test-taking techniques, time management, and gain familiarity with all exam formats for FCE, CAE, and CPE levels.',
      color: '#d4a5c6', // Pastel purple/pink
    },
    {
      icon: BookOpen,
      title: t('spec_matura'),
      frontDescription: t('spec_matura_desc'),
      backDescription: 'Complete MATURA exam preparation covering all required skills: reading comprehension, writing, listening, and speaking. Personalized approach focusing on Polish curriculum requirements and exam strategies.',
      color: '#f5c5b8', // Pastel coral/peach
    },
  ];

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#b8d4e8] via-[#d4a5c6] to-[#f5c5b8] text-white py-20 overflow-hidden">
        <div className="absolute inset-0 bg-white/5"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <Badge className="bg-white/20 text-white border-white/30 backdrop-blur">
                ✨ Personally Crafted English Lessons
              </Badge>
              <h1 className="text-5xl md:text-6xl font-bold leading-tight" style={{ fontFamily: 'Dancing Script, cursive' }}>
                {t('hero_title')}
              </h1>
              <p className="text-xl text-white/90">
                {t('hero_subtitle')}
              </p>
              <p className="text-lg text-white/80 italic">
                Every lesson is personally designed by me to match your unique learning style and goals
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  onClick={() => navigate(user ? '/booking' : '/signup')}
                  className="bg-white hover:bg-gray-100 shadow-lg"
                  style={{ color: '#d4a5c6' }}
                >
                  {t('cta_trial')}
                </Button>
              </div>
            </div>
            <div className="hidden md:block">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent rounded-2xl blur-2xl"></div>
                <img 
                  src={logo} 
                  alt="Spark English" 
                  className="rounded-2xl relative z-10 w-full max-w-md mx-auto drop-shadow-2xl"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Me Section */}
      <section className="py-16 bg-gradient-to-br from-[#f5c5b8]/20 via-white to-[#d4a5c6]/20">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold mb-4" style={{ fontFamily: 'Dancing Script, cursive', color: '#a8b5d4' }}>
                About Me
              </h2>
            </div>
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="order-2 md:order-1">
                <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                  <img 
                    src={aboutMeImage} 
                    alt="Celine Kleynhans" 
                    className="w-full h-auto object-cover"
                  />
                </div>
              </div>
              <div className="order-1 md:order-2 space-y-4">
                <p className="text-lg text-gray-700 leading-relaxed">
                  I'm Celine Kleynhans, a 25-year-old with six years of experience in education. I've always been dedicated to creating a positive and engaging environment for children. Over the years, I've developed strong skills in planning and assessment, ensuring that every child I work with feels supported, motivated, and stimulated.
                </p>
                <p className="text-lg text-gray-700 leading-relaxed">
                  I am hardworking, kind, and work well within a team, which I believe is essential in any educational setting. My passion for teaching drives me to keep learning and growing, always striving to make a meaningful and lasting impact.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4" style={{ fontFamily: 'Dancing Script, cursive', color: '#a8b5d4' }}>
              {t('how_it_works')}
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Start your English learning journey in three simple steps
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: Users, title: t('step1_title'), desc: t('step1_desc'), number: '01', color: '#b8d4e8' },
              { icon: TrendingUp, title: t('step2_title'), desc: t('step2_desc'), number: '02', color: '#d4a5c6' },
              { icon: Award, title: t('step3_title'), desc: t('step3_desc'), number: '03', color: '#f5c5b8' },
            ].map((step, index) => (
              <div key={index} className="relative">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="relative">
                    <div className="absolute -top-6 -right-6 text-6xl font-bold text-gray-100">
                      {step.number}
                    </div>
                    <div 
                      className="relative z-10 w-20 h-20 rounded-2xl flex items-center justify-center shadow-lg"
                      style={{ backgroundColor: step.color }}
                    >
                      <step.icon className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold" style={{ fontFamily: 'Dancing Script, cursive' }}>{step.title}</h3>
                  <p className="text-gray-600">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Specializations with Flip Cards */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4" style={{ fontFamily: 'Dancing Script, cursive', color: '#a8b5d4' }}>
              {t('specializations')}
            </h2>
            <p className="text-gray-600">Expert instruction in multiple areas - hover or tap to learn more</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {specializations.map((spec, index) => (
              <FlipCard
                key={index}
                icon={spec.icon}
                title={spec.title}
                frontDescription={spec.frontDescription}
                backDescription={spec.backDescription}
                color={spec.color}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-gradient-to-br from-[#b8d4e8]/30 via-[#d4a5c6]/30 to-[#f5c5b8]/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-4xl font-bold mb-4" style={{ fontFamily: 'Dancing Script, cursive', color: '#a8b5d4' }}>
                {t('contact_title')}
              </h2>
              <p className="text-gray-600">{t('contact_subtitle')}</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-8">
              {/* Contact Info Cards */}
              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow" style={{ backgroundColor: '#b8d4e8' }}>
                <CardContent className="p-6 text-center text-white">
                  <Mail className="h-12 w-12 mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'Dancing Script, cursive' }}>Email Me</h3>
                  <a 
                    href="mailto:spark.englishck@gmail.com" 
                    className="text-white/90 hover:text-white underline"
                  >
                    spark.englishck@gmail.com
                  </a>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow" style={{ backgroundColor: '#d4a5c6' }}>
                <CardContent className="p-6 text-center text-white">
                  <MessageSquare className="h-12 w-12 mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'Dancing Script, cursive' }}>WhatsApp</h3>
                  <a 
                    href="https://wa.me/27780817403" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-white/90 hover:text-white underline"
                  >
                    +27 78 081 7403
                  </a>
                </CardContent>
              </Card>
            </div>

            <Card className="border-none shadow-xl">
              <CardContent className="p-8">
                <form onSubmit={handleContactSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">{t('name')}</label>
                    <Input
                      value={contactForm.name}
                      onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                      placeholder={t('name')}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">{t('email')}</label>
                    <Input
                      type="email"
                      value={contactForm.email}
                      onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                      placeholder={t('email')}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">{t('message')}</label>
                    <Textarea
                      value={contactForm.message}
                      onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                      placeholder={t('message')}
                      rows={5}
                      required
                    />
                  </div>
                  <Button 
                    type="submit" 
                    size="lg" 
                    className="w-full text-white hover:opacity-90" 
                    style={{ backgroundColor: '#d4a5c6' }}
                  >
                    {t('send')}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <img src={logo} alt="Spark English" className="h-8 w-8" />
            <span className="text-xl" style={{ fontFamily: 'Pacifico, cursive', color: '#d4a5c6' }}>
              Spark English
            </span>
          </div>
          <p className="text-gray-400 mb-2">Personally crafted English lessons for your success</p>
          <div className="flex justify-center gap-6 text-sm text-gray-400">
            <a href="mailto:spark.englishck@gmail.com" className="hover:text-[#d4a5c6] transition-colors">
              spark.englishck@gmail.com
            </a>
            <span>•</span>
            <a href="https://wa.me/27780817403" target="_blank" rel="noopener noreferrer" className="hover:text-[#d4a5c6] transition-colors">
              +27 78 081 7403
            </a>
          </div>
          <p className="text-gray-500 mt-4 text-sm">© 2026 Spark English. {t('footer_rights')}</p>
        </div>
      </footer>
    </div>
  );
}