import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Calendar } from '../components/ui/calendar';
import { Label } from '../components/ui/label';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { Badge } from '../components/ui/badge';
import { toast } from 'sonner';
import { CalendarIcon, Clock, Gift } from 'lucide-react';

export default function Booking() {
  const { user, updateUser } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [date, setDate] = useState<Date>();
  const [time, setTime] = useState('');
  const [lessonType, setLessonType] = useState<'trial' | 'regular' | 'free'>('trial');
  const [hasTrialLesson, setHasTrialLesson] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    // Check if user already has a trial lesson
    const lessonsData = localStorage.getItem(`lessons_${user.id}`);
    if (lessonsData) {
      const lessons = JSON.parse(lessonsData);
      const hasTrial = lessons.some((l: any) => l.type === 'trial');
      setHasTrialLesson(hasTrial);
      if (hasTrial) {
        setLessonType('regular');
      }
    }
  }, [user, navigate]);

  if (!user) return null;

  const timeSlots = [
    '09:00', '10:00', '11:00', '12:00', '13:00', '14:00',
    '15:00', '16:00', '17:00', '18:00', '19:00', '20:00'
  ];

  const handleBooking = () => {
    if (!date || !time) {
      toast.error('Please select both date and time');
      return;
    }

    if (lessonType === 'free' && user.freeLessons === 0) {
      toast.error('You don\'t have any free lessons available');
      return;
    }

    // Create booking
    const [hours, minutes] = time.split(':');
    const bookingDate = new Date(date);
    bookingDate.setHours(parseInt(hours), parseInt(minutes), 0, 0);

    const lessonsData = localStorage.getItem(`lessons_${user.id}`);
    const lessons = lessonsData ? JSON.parse(lessonsData) : [];

    const newLesson = {
      id: Date.now().toString(),
      date: bookingDate.toISOString(),
      type: lessonType,
      status: 'upcoming',
      userId: user.id,
      userName: user.name,
    };

    lessons.push(newLesson);
    localStorage.setItem(`lessons_${user.id}`, JSON.stringify(lessons));

    // Also save to global lessons list for owner tracking
    const allLessonsData = localStorage.getItem('all_lessons');
    const allLessons = allLessonsData ? JSON.parse(allLessonsData) : [];
    allLessons.push(newLesson);
    localStorage.setItem('all_lessons', JSON.stringify(allLessons));

    // Use free lesson if selected
    if (lessonType === 'free') {
      updateUser({ freeLessons: user.freeLessons - 1 });
    }

    // Track referral bookings
    if (user.referredBy) {
      trackReferralBooking(user.referredBy, user.id);
    }

    toast.success('Lesson booked successfully!');
    navigate('/dashboard');
  };

  const trackReferralBooking = (referralCode: string, userId: string) => {
    const referralsData = localStorage.getItem('referrals');
    const referrals = referralsData ? JSON.parse(referralsData) : {};

    if (referrals[referralCode]) {
      const referral = referrals[referralCode].find((r: any) => r.userId === userId);
      if (referral) {
        referral.bookings += 1;

        // Update referral stats for owner
        const referralStatsData = localStorage.getItem('referral_stats');
        const referralStats = referralStatsData ? JSON.parse(referralStatsData) : {};
        
        if (!referralStats[referralCode]) {
          referralStats[referralCode] = [];
        }
        
        const statsEntry = referralStats[referralCode].find((r: any) => r.userId === userId);
        if (statsEntry) {
          statsEntry.bookings = referral.bookings;
          statsEntry.userName = user.name;
          statsEntry.userEmail = user.email;
        } else {
          referralStats[referralCode].push({
            userId,
            bookings: referral.bookings,
            userName: user.name,
            userEmail: user.email,
          });
        }
        
        localStorage.setItem('referral_stats', JSON.stringify(referralStats));

        // Award free lesson after 4 bookings
        if (referral.bookings === 4) {
          const usersData = localStorage.getItem('users');
          const users = usersData ? JSON.parse(usersData) : [];
          const referrer = users.find((u: any) => u.referralCode === referralCode);

          if (referrer) {
            referrer.freeLessons = (referrer.freeLessons || 0) + 1;
            localStorage.setItem('users', JSON.stringify(users));

            // Update current user if they are the referrer
            if (user.referralCode === referralCode) {
              updateUser({ freeLessons: referrer.freeLessons });
            }

            toast.success('🎉 A friend earned a free lesson through your referral!');
          }
        }

        localStorage.setItem('referrals', JSON.stringify(referrals));
      }
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-12 px-4">
      <div className="container mx-auto max-w-4xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">{t('book_lesson')}</h1>
          <p className="text-gray-600">Schedule your next English lesson</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Lesson Type Selection */}
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>{t('select_type')}</CardTitle>
              <CardDescription>Choose the type of lesson you'd like to book</CardDescription>
            </CardHeader>
            <CardContent>
              <RadioGroup value={lessonType} onValueChange={(value: any) => setLessonType(value)} className="space-y-3">
                {!hasTrialLesson && (
                  <label
                    htmlFor="trial"
                    className={`flex items-start gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 ${
                      lessonType === 'trial'
                        ? 'border-[#7ab3d4] bg-[#b8d4e8]/40 shadow-md'
                        : 'border-[#b8d4e8] bg-[#b8d4e8]/10 hover:bg-[#b8d4e8]/25'
                    }`}
                  >
                    <div className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                      lessonType === 'trial' ? 'border-[#7ab3d4] bg-[#7ab3d4]' : 'border-gray-400 bg-white'
                    }`}>
                      {lessonType === 'trial' && <div className="w-2 h-2 rounded-full bg-white" />}
                    </div>
                    <RadioGroupItem value="trial" id="trial" className="sr-only" />
                    <div className="flex-1">
                      <span className="font-semibold text-gray-800">{t('trial_lesson')}</span>
                      <p className="text-sm text-gray-600 mt-1">
                        Experience our personalized teaching method with your first lesson
                      </p>
                    </div>
                  </label>
                )}

                <label
                  htmlFor="regular"
                  className={`flex items-start gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 ${
                    lessonType === 'regular'
                      ? 'border-[#b87abf] bg-[#d4a5c6]/40 shadow-md'
                      : 'border-[#d4a5c6] bg-[#d4a5c6]/10 hover:bg-[#d4a5c6]/25'
                  }`}
                >
                  <div className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                    lessonType === 'regular' ? 'border-[#b87abf] bg-[#b87abf]' : 'border-gray-400 bg-white'
                  }`}>
                    {lessonType === 'regular' && <div className="w-2 h-2 rounded-full bg-white" />}
                  </div>
                  <RadioGroupItem value="regular" id="regular" className="sr-only" />
                  <div className="flex-1">
                    <span className="font-semibold text-gray-800">{t('regular_lesson')}</span>
                    <p className="text-sm text-gray-600 mt-1">
                      Standard 60-minute personalized lesson
                    </p>
                  </div>
                </label>

                {user.freeLessons > 0 && (
                  <label
                    htmlFor="free"
                    className={`flex items-start gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 ${
                      lessonType === 'free'
                        ? 'border-[#5aaa5e] bg-[#c8e6c9]/40 shadow-md'
                        : 'border-[#a8d5a5] bg-[#c8e6c9]/10 hover:bg-[#c8e6c9]/25'
                    }`}
                  >
                    <div className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                      lessonType === 'free' ? 'border-[#5aaa5e] bg-[#5aaa5e]' : 'border-gray-400 bg-white'
                    }`}>
                      {lessonType === 'free' && <div className="w-2 h-2 rounded-full bg-white" />}
                    </div>
                    <RadioGroupItem value="free" id="free" className="sr-only" />
                    <div className="flex-1">
                      <span className="font-semibold text-gray-800 flex items-center gap-2">
                        {t('use_free_lesson')}
                        <Gift className="h-4 w-4 text-[#5aaa5e]" />
                      </span>
                      <p className="text-sm text-gray-600 mt-1">
                        You have {user.freeLessons} free lesson{user.freeLessons !== 1 ? 's' : ''} available from referrals
                      </p>
                    </div>
                  </label>
                )}
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Date & Time Selection */}
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>{t('select_date')}</CardTitle>
              <CardDescription>Pick a convenient date and time</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="mb-3 flex items-center gap-2">
                  <CalendarIcon className="h-4 w-4" />
                  Select Date
                </Label>
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  disabled={(date) => date < new Date() || date.getDay() === 0}
                  className="rounded-md border"
                />
              </div>

              {date && (
                <div>
                  <Label className="mb-3 flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Select Time
                  </Label>
                  <div className="grid grid-cols-3 gap-2">
                    {timeSlots.map((slot) => (
                      <Button
                        key={slot}
                        variant={time === slot ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setTime(slot)}
                      >
                        {slot}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Booking Summary */}
        {date && time && (
          <Card className="mt-6 border-none shadow-lg bg-gradient-to-br from-blue-600 to-purple-600 text-white">
            <CardHeader>
              <CardTitle className="text-2xl">Booking Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 mb-6">
                <div className="flex justify-between items-center">
                  <span className="text-white/80">Lesson Type:</span>
                  <span className="font-semibold">
                    {lessonType === 'trial' ? t('trial_lesson') : lessonType === 'free' ? t('use_free_lesson') : t('regular_lesson')}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-white/80">Date:</span>
                  <span className="font-semibold">{date.toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-white/80">Time:</span>
                  <span className="font-semibold">{time}</span>
                </div>
              </div>
              <Button
                size="lg"
                onClick={handleBooking}
                className="w-full bg-white text-purple-600 hover:bg-gray-100"
              >
                {t('confirm_booking')}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}