import { Outlet } from 'react-router';
import { AuthProvider } from '../contexts/AuthContext';
import { LanguageProvider } from '../contexts/LanguageContext';
import Header from '../components/Header';
import { Toaster } from '../components/ui/sonner';

export default function Root() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <div className="min-h-screen bg-gray-50">
          <Header />
          <main>
            <Outlet />
          </main>
          <Toaster />
        </div>
      </LanguageProvider>
    </AuthProvider>
  );
}
