import { useState } from 'react';
import { useNavigate, Link } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';
import logo from 'figma:asset/c8a08fa9aab5e1bd052a2d62be355f3147370a48.png';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await login(email, password);
    
    if (success) {
      toast.success('Welcome back!');
      navigate('/dashboard');
    } else {
      toast.error('Invalid email or password');
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gradient-to-br from-[#b8d4e8]/30 via-[#d4a5c6]/30 to-[#f5c5b8]/30 py-12 px-4">
      <Card className="w-full max-w-md shadow-xl border-none">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <img src={logo} alt="Spark English" className="h-20 w-20" />
          </div>
          <CardTitle className="text-3xl" style={{ fontFamily: 'Dancing Script, cursive', color: '#a8b5d4' }}>
            {t('login')}
          </CardTitle>
          <CardDescription>Welcome back to your English learning journey</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">{t('email_label')}</Label>
              <Input
                id="email"
                type="email"
                placeholder={t('email')}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">{t('password')}</Label>
              <Input
                id="password"
                type="password"
                placeholder={t('password')}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <Button 
              type="submit" 
              className="w-full text-white" 
              size="lg"
              style={{ backgroundColor: '#d4a5c6' }}
            >
              {t('login')}
            </Button>
          </form>
          <div className="mt-6 text-center text-sm">
            <span className="text-gray-600">{t('no_account')} </span>
            <Link to="/signup" className="hover:underline font-medium" style={{ color: '#d4a5c6' }}>
              {t('signup')}
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}