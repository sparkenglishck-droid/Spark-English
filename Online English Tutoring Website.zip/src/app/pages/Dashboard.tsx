import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Calendar, Gift, BookOpen, TrendingUp, Users, Award, Eye } from 'lucide-react';
import { format } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';

interface Lesson {
  id: string;
  date: Date;
  type: 'trial' | 'regular' | 'free';
  status: 'upcoming' | 'completed';
  userId?: string;
  userName?: string;
}

interface ReferralData {
  userId: string;
  bookings: number;
  userName?: string;
  userEmail?: string;
}

export default function Dashboard() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [allLessons, setAllLessons] = useState<Lesson[]>([]);
  const [referralStats, setReferralStats] = useState<{ [code: string]: ReferralData[] }>({});
  
  // Owner email - you can change this to your actual email
  const isOwner = user?.email === 'spark.englishck@gmail.com';

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    // Load lessons from localStorage
    const lessonsData = localStorage.getItem(`lessons_${user.id}`);
    if (lessonsData) {
      const parsed = JSON.parse(lessonsData);
      setLessons(parsed.map((l: any) => ({ ...l, date: new Date(l.date) })));
    }

    // Load all lessons from localStorage for owner
    if (isOwner) {
      const allLessonsData = localStorage.getItem('all_lessons');
      if (allLessonsData) {
        const parsed = JSON.parse(allLessonsData);
        setAllLessons(parsed.map((l: any) => ({ ...l, date: new Date(l.date) })));
      }
    }

    // Load referral stats from localStorage
    const referralStatsData = localStorage.getItem('referral_stats');
    if (referralStatsData) {
      const parsed = JSON.parse(referralStatsData);
      setReferralStats(parsed);
    }
  }, [user, navigate, isOwner]);

  if (!user) return null;

  const upcomingLessons = lessons
    .filter(l => l.status === 'upcoming')
    .sort((a, b) => a.date.getTime() - b.date.getTime());

  const completedLessons = lessons
    .filter(l => l.status === 'completed')
    .sort((a, b) => b.date.getTime() - a.date.getTime());

  const stats = [
    {
      icon: Calendar,
      label: t('upcoming_lessons'),
      value: upcomingLessons.length,
      color: 'from-[#b8d4e8] to-[#a8c8dc]',
    },
    {
      icon: BookOpen,
      label: t('past_lessons'),
      value: completedLessons.length,
      color: 'from-[#d4a5c6] to-[#c495b6]',
    },
    {
      icon: Gift,
      label: t('free_lessons'),
      value: user.freeLessons,
      color: 'from-[#f5c5b8] to-[#e5b5a8]',
    },
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Welcome back, {user.name}! 👋</h1>
          <p className="text-gray-600">Here's your learning progress</p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="border-none shadow-lg">
              <CardHeader className="pb-3">
                <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center mb-3`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <CardDescription>{stat.label}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <Card className="mb-8 border-none shadow-lg bg-gradient-to-br from-blue-600 to-purple-600 text-white">
          <CardHeader>
            <CardTitle className="text-2xl">Ready for your next lesson?</CardTitle>
            <CardDescription className="text-white/80">
              Book a new lesson or use one of your free lessons
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                onClick={() => navigate('/booking')}
                className="bg-white text-purple-600 hover:bg-gray-100"
              >
                <Calendar className="mr-2 h-5 w-5" />
                {t('book_lesson')}
              </Button>
              <Button
                size="lg"
                onClick={() => navigate('/referrals')}
                variant="outline"
                className="border-white text-white hover:bg-white/10"
              >
                <TrendingUp className="mr-2 h-5 w-5" />
                {t('share_earn')}
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Upcoming Lessons */}
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-blue-600" />
                {t('upcoming_lessons')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {upcomingLessons.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p>No upcoming lessons scheduled</p>
                  <Button
                    onClick={() => navigate('/booking')}
                    variant="link"
                    className="mt-2"
                  >
                    Book your first lesson
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {upcomingLessons.map((lesson) => (
                    <div
                      key={lesson.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                    >
                      <div>
                        <p className="font-medium">
                          {format(lesson.date, 'EEEE, MMMM d, yyyy')}
                        </p>
                        <p className="text-sm text-gray-600">
                          {format(lesson.date, 'h:mm a')}
                        </p>
                      </div>
                      <Badge
                        variant={lesson.type === 'trial' ? 'default' : lesson.type === 'free' ? 'secondary' : 'outline'}
                      >
                        {lesson.type === 'trial' ? 'Trial' : lesson.type === 'free' ? 'Free' : 'Regular'}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Past Lessons */}
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-purple-600" />
                {t('past_lessons')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {completedLessons.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p>No completed lessons yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {completedLessons.slice(0, 5).map((lesson) => (
                    <div
                      key={lesson.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                    >
                      <div>
                        <p className="font-medium">
                          {format(lesson.date, 'EEEE, MMMM d, yyyy')}
                        </p>
                        <p className="text-sm text-gray-600">
                          {format(lesson.date, 'h:mm a')}
                        </p>
                      </div>
                      <Badge variant="outline">Completed</Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Owner Dashboard */}
        {isOwner && (
          <div className="mt-12">
            <Card className="border-none shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Eye className="h-6 w-6 text-purple-600" />
                  Owner Dashboard - Track All Activity
                </CardTitle>
                <CardDescription>
                  View all bookings and referral activity across all students
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="lessons" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 mb-6">
                    <TabsTrigger value="lessons" className="text-base">
                      <Calendar className="h-4 w-4 mr-2" />
                      All Lessons
                    </TabsTrigger>
                    <TabsTrigger value="referrals" className="text-base">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      Referral Tracking
                    </TabsTrigger>
                    <TabsTrigger value="stats" className="text-base">
                      <Award className="h-4 w-4 mr-2" />
                      Overall Stats
                    </TabsTrigger>
                  </TabsList>

                  {/* All Lessons Tab */}
                  <TabsContent value="lessons" className="space-y-4">
                    <div className="rounded-lg border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Student Name</TableHead>
                            <TableHead>Date & Time</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Status</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {allLessons.length === 0 ? (
                            <TableRow>
                              <TableCell colSpan={4} className="text-center py-8 text-gray-500">
                                No lessons booked yet
                              </TableCell>
                            </TableRow>
                          ) : (
                            allLessons
                              .sort((a, b) => b.date.getTime() - a.date.getTime())
                              .map((lesson) => (
                                <TableRow key={lesson.id}>
                                  <TableCell className="font-medium">
                                    {lesson.userName || 'Unknown Student'}
                                  </TableCell>
                                  <TableCell>
                                    <div>
                                      <p className="font-medium">{format(lesson.date, 'MMM d, yyyy')}</p>
                                      <p className="text-sm text-gray-600">{format(lesson.date, 'h:mm a')}</p>
                                    </div>
                                  </TableCell>
                                  <TableCell>
                                    <Badge
                                      variant={lesson.type === 'trial' ? 'default' : lesson.type === 'free' ? 'secondary' : 'outline'}
                                    >
                                      {lesson.type === 'trial' ? 'Trial' : lesson.type === 'free' ? 'Free' : 'Regular'}
                                    </Badge>
                                  </TableCell>
                                  <TableCell>
                                    <Badge variant={lesson.status === 'upcoming' ? 'default' : 'outline'}>
                                      {lesson.status === 'upcoming' ? 'Upcoming' : 'Completed'}
                                    </Badge>
                                  </TableCell>
                                </TableRow>
                              ))
                          )}
                        </TableBody>
                      </Table>
                    </div>
                  </TabsContent>

                  {/* Referrals Tab */}
                  <TabsContent value="referrals" className="space-y-4">
                    <div className="rounded-lg border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Referral Code</TableHead>
                            <TableHead>Referred Student</TableHead>
                            <TableHead>Email</TableHead>
                            <TableHead>Bookings Made</TableHead>
                            <TableHead>Progress</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {Object.keys(referralStats).length === 0 ? (
                            <TableRow>
                              <TableCell colSpan={5} className="text-center py-8 text-gray-500">
                                No referral activity yet
                              </TableCell>
                            </TableRow>
                          ) : (
                            Object.entries(referralStats).flatMap(([code, referrals]) =>
                              referrals.map((referral) => (
                                <TableRow key={`${code}-${referral.userId}`}>
                                  <TableCell>
                                    <Badge variant="outline" className="font-mono">
                                      {code}
                                    </Badge>
                                  </TableCell>
                                  <TableCell className="font-medium">
                                    {referral.userName || 'Unknown'}
                                  </TableCell>
                                  <TableCell className="text-sm text-gray-600">
                                    {referral.userEmail || 'N/A'}
                                  </TableCell>
                                  <TableCell>
                                    <span className="font-semibold">{referral.bookings}</span> / 4
                                  </TableCell>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                                        <div
                                          className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                                          style={{ width: `${(referral.bookings / 4) * 100}%` }}
                                        />
                                      </div>
                                      {referral.bookings >= 4 && (
                                        <Gift className="h-4 w-4 text-green-500" />
                                      )}
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))
                            )
                          )}
                        </TableBody>
                      </Table>
                    </div>
                  </TabsContent>

                  {/* Stats Tab */}
                  <TabsContent value="stats" className="space-y-6">
                    <div className="grid md:grid-cols-3 gap-6">
                      <Card className="border-2" style={{ borderColor: '#b8d4e8' }}>
                        <CardHeader className="pb-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-[#b8d4e8] to-[#a8c8dc] rounded-xl flex items-center justify-center mb-3">
                            <Calendar className="h-6 w-6 text-white" />
                          </div>
                          <CardDescription>Total Upcoming Lessons</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="text-3xl font-bold">
                            {allLessons.filter(l => l.status === 'upcoming').length}
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="border-2" style={{ borderColor: '#d4a5c6' }}>
                        <CardHeader className="pb-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-[#d4a5c6] to-[#c495b6] rounded-xl flex items-center justify-center mb-3">
                            <BookOpen className="h-6 w-6 text-white" />
                          </div>
                          <CardDescription>Total Completed Lessons</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="text-3xl font-bold">
                            {allLessons.filter(l => l.status === 'completed').length}
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="border-2" style={{ borderColor: '#f5c5b8' }}>
                        <CardHeader className="pb-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-[#f5c5b8] to-[#e5b5a8] rounded-xl flex items-center justify-center mb-3">
                            <Gift className="h-6 w-6 text-white" />
                          </div>
                          <CardDescription>Free Lessons Awarded</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="text-3xl font-bold">
                            {allLessons.filter(l => l.type === 'free').length}
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <Card className="border-2" style={{ borderColor: '#a8d5a5' }}>
                        <CardHeader className="pb-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-[#a8d5a5] to-[#8bc58a] rounded-xl flex items-center justify-center mb-3">
                            <Users className="h-6 w-6 text-white" />
                          </div>
                          <CardDescription>Total Referrals</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="text-3xl font-bold">
                            {Object.values(referralStats).reduce((acc, refs) => acc + refs.length, 0)}
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="border-2" style={{ borderColor: '#ffd59e' }}>
                        <CardHeader className="pb-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-[#ffd59e] to-[#ffc56e] rounded-xl flex items-center justify-center mb-3">
                            <TrendingUp className="h-6 w-6 text-white" />
                          </div>
                          <CardDescription>Trial Lessons Booked</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="text-3xl font-bold">
                            {allLessons.filter(l => l.type === 'trial').length}
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}