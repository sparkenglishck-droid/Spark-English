import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Copy, Share2, Gift, Users, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';

interface ReferralData {
  userId: string;
  bookings: number;
}

export default function Referrals() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [referrals, setReferrals] = useState<ReferralData[]>([]);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    // Load referral data
    const referralsData = localStorage.getItem('referrals');
    if (referralsData) {
      const allReferrals = JSON.parse(referralsData);
      const userReferrals = allReferrals[user.referralCode] || [];
      setReferrals(userReferrals);
    }
  }, [user, navigate]);

  if (!user) return null;

  const copyReferralCode = () => {
    navigator.clipboard.writeText(user.referralCode);
    toast.success('Referral code copied to clipboard!');
  };

  const shareReferral = () => {
    const text = `Join me on English Academy! Use my referral code "${user.referralCode}" when signing up and we both benefit. Start your English learning journey today!`;
    
    if (navigator.share) {
      navigator.share({
        title: 'Join English Academy',
        text: text,
      }).catch(() => {
        navigator.clipboard.writeText(text);
        toast.success('Referral message copied to clipboard!');
      });
    } else {
      navigator.clipboard.writeText(text);
      toast.success('Referral message copied to clipboard!');
    }
  };

  const totalBookings = referrals.reduce((sum, r) => sum + r.bookings, 0);
  const earnedLessons = Math.floor(totalBookings / 4);
  const progressToNextLesson = totalBookings % 4;

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-12 px-4">
      <div className="container mx-auto max-w-5xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">{t('referrals')}</h1>
          <p className="text-gray-600">{t('share_earn')}</p>
        </div>

        {/* Referral Code Card */}
        <Card className="mb-8 border-none shadow-xl text-white" style={{ background: 'linear-gradient(135deg, #b8d4e8 0%, #d4a5c6 50%, #f5c5b8 100%)' }}>
          <CardHeader>
            <CardTitle className="text-3xl flex items-center gap-3" style={{ fontFamily: 'Dancing Script, cursive' }}>
              <Gift className="h-8 w-8" />
              {t('my_referral_code')}
            </CardTitle>
            <CardDescription className="text-white/90 text-base">
              {t('referral_instructions')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-white/10 backdrop-blur rounded-xl p-6 mb-6">
              <div className="text-center">
                <p className="text-sm text-white/70 mb-2">Your Referral Code</p>
                <p className="text-5xl font-bold tracking-wider mb-4">{user.referralCode}</p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button
                    onClick={copyReferralCode}
                    size="lg"
                    className="bg-white text-purple-600 hover:bg-gray-100"
                  >
                    <Copy className="mr-2 h-5 w-5" />
                    Copy Code
                  </Button>
                  <Button
                    onClick={shareReferral}
                    size="lg"
                    className="bg-white/20 border-2 border-white text-white hover:bg-white/30 backdrop-blur"
                  >
                    <Share2 className="mr-2 h-5 w-5" />
                    Share
                  </Button>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-white/10 backdrop-blur rounded-lg p-4 text-center">
                <Users className="h-8 w-8 mx-auto mb-2" />
                <p className="text-2xl font-bold">{referrals.length}</p>
                <p className="text-sm text-white/80">Friends Referred</p>
              </div>
              <div className="bg-white/10 backdrop-blur rounded-lg p-4 text-center">
                <TrendingUp className="h-8 w-8 mx-auto mb-2" />
                <p className="text-2xl font-bold">{totalBookings}</p>
                <p className="text-sm text-white/80">Total Bookings</p>
              </div>
              <div className="bg-white/10 backdrop-blur rounded-lg p-4 text-center">
                <Gift className="h-8 w-8 mx-auto mb-2" />
                <p className="text-2xl font-bold">{earnedLessons}</p>
                <p className="text-sm text-white/80">Lessons Earned</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Progress to Next Free Lesson */}
        <Card className="mb-8 border-none shadow-lg">
          <CardHeader>
            <CardTitle>Progress to Next Free Lesson</CardTitle>
            <CardDescription>
              {4 - progressToNextLesson} more booking{4 - progressToNextLesson !== 1 ? 's' : ''} needed
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600">Progress</span>
                <span className="text-sm font-medium">{progressToNextLesson} / 4</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-blue-600 to-purple-600 h-full rounded-full transition-all duration-500"
                  style={{ width: `${(progressToNextLesson / 4) * 100}%` }}
                />
              </div>
              <div className="flex justify-between">
                {[1, 2, 3, 4].map((num) => (
                  <div
                    key={num}
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                      num <= progressToNextLesson
                        ? 'bg-gradient-to-br from-blue-600 to-purple-600 text-white'
                        : 'bg-gray-200 text-gray-400'
                    }`}
                  >
                    {num}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Referral Activity */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>{t('bookings_made')}</CardTitle>
            <CardDescription>Track your friends' booking activity</CardDescription>
          </CardHeader>
          <CardContent>
            {referrals.length === 0 ? (
              <div className="text-center py-12">
                <Users className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500 mb-4">No referrals yet</p>
                <p className="text-sm text-gray-400 mb-6">
                  Share your referral code to start earning free lessons!
                </p>
                <Button onClick={copyReferralCode}>
                  <Copy className="mr-2 h-4 w-4" />
                  Copy Referral Code
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {referrals.map((referral, index) => (
                  <div
                    key={referral.userId}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-medium">Referral #{index + 1}</p>
                        <p className="text-sm text-gray-600">
                          {referral.bookings} booking{referral.bookings !== 1 ? 's' : ''} completed
                        </p>
                      </div>
                    </div>
                    <div>
                      {referral.bookings >= 4 ? (
                        <Badge className="bg-green-600">
                          <Gift className="mr-1 h-3 w-3" />
                          Lesson Earned!
                        </Badge>
                      ) : (
                        <Badge variant="outline">
                          {4 - referral.bookings} more to free lesson
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}