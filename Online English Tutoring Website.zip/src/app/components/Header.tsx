import { Link, useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Globe } from 'lucide-react';
import logo from 'figma:asset/c8a08fa9aab5e1bd052a2d62be355f3147370a48.png';

export default function Header() {
  const { user, logout } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="container mx-auto px-4 flex h-20 items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <img src={logo} alt="Spark English" className="h-12 w-12 object-contain" />
          <span className="text-2xl font-bold" style={{ fontFamily: 'Times New Roman, serif', color: '#a8b5d4' }}>
            Spark English
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          <Link to="/" className="text-sm font-medium hover:text-[#d4a5c6] transition-colors">
            {t('home')}
          </Link>
          {user && (
            <>
              <Link to="/dashboard" className="text-sm font-medium hover:text-[#d4a5c6] transition-colors">
                {t('dashboard')}
              </Link>
              <Link to="/booking" className="text-sm font-medium hover:text-[#d4a5c6] transition-colors">
                {t('booking')}
              </Link>
              <Link to="/referrals" className="text-sm font-medium hover:text-[#d4a5c6] transition-colors">
                {t('referrals')}
              </Link>
            </>
          )}
        </nav>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Globe className="h-4 w-4 text-gray-500" />
            <Select value={language} onValueChange={(value) => setLanguage(value as any)}>
              <SelectTrigger className="w-[100px] h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="es">Español</SelectItem>
                <SelectItem value="fr">Français</SelectItem>
                <SelectItem value="de">Deutsch</SelectItem>
                <SelectItem value="pl">Polski</SelectItem>
                <SelectItem value="pt">Português</SelectItem>
                <SelectItem value="zh">中文</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {user ? (
            <div className="flex items-center gap-3">
              <span className="text-sm text-gray-600 hidden md:inline">
                {user.name}
              </span>
              <Button onClick={handleLogout} variant="outline" size="sm">
                {t('logout')}
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Button onClick={() => navigate('/login')} variant="ghost" size="sm">
                {t('login')}
              </Button>
              <Button onClick={() => navigate('/signup')} size="sm" style={{ backgroundColor: '#d4a5c6' }}>
                {t('signup')}
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}