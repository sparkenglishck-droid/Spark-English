import { useState } from 'react';
import { Card } from './ui/card';
import { LucideIcon } from 'lucide-react';

interface FlipCardProps {
  icon: LucideIcon;
  title: string;
  frontDescription: string;
  backDescription: string;
  color: string;
}

export default function FlipCard({ icon: Icon, title, frontDescription, backDescription, color }: FlipCardProps) {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div 
      className="relative h-[320px] cursor-pointer perspective-1000"
      onMouseEnter={() => setIsFlipped(true)}
      onMouseLeave={() => setIsFlipped(false)}
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <div 
        className={`relative w-full h-full transition-transform duration-700 transform-style-3d ${
          isFlipped ? 'rotate-y-180' : ''
        }`}
        style={{ transformStyle: 'preserve-3d' }}
      >
        {/* Front */}
        <Card 
          className="absolute w-full h-full backface-hidden border-none shadow-lg hover:shadow-xl transition-shadow"
          style={{ 
            backfaceVisibility: 'hidden',
            backgroundColor: color,
          }}
        >
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-white">
            <div className="w-20 h-20 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center mb-6 shadow-lg">
              <Icon className="h-10 w-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: 'Dancing Script, cursive' }}>
              {title}
            </h3>
            <p className="text-white/90 text-sm leading-relaxed">
              {frontDescription}
            </p>
          </div>
        </Card>

        {/* Back */}
        <Card 
          className="absolute w-full h-full backface-hidden border-none shadow-xl"
          style={{ 
            backfaceVisibility: 'hidden',
            transform: 'rotateY(180deg)',
            backgroundColor: color,
          }}
        >
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-white">
            <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: 'Dancing Script, cursive' }}>
              What You'll Learn
            </h3>
            <p className="text-white/95 text-sm leading-relaxed">
              {backDescription}
            </p>
            <div className="mt-4 text-xs text-white/70 italic">
              Tap or hover for details
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
